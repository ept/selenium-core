namespace Selenium
{
	public class Skeleton
	{
		public object SayHelloWorld()
		{
			return "HelloWorld";
		}
	}
}
