namespace Selenium
{
	/// <summary>
	/// Summary description for SeleneseCommand.
	/// </summary>
	public interface ISeleneseCommand
	{
		string CommandString { get; }
	}
}